-- Decompiled with Potassium's decompiler.

local u1 = nil;

local function findClosestDriveSeat(p2) -- Line: 3
    -- upvalues: u1 (ref)
    local Character = p2.Character;
    local v3 = 15;
    local v4 = nil;

    for _, descendant in ipairs(workspace:GetDescendants()) do
        if descendant:IsA("VehicleSeat") then
            local Magnitude = (descendant.Position - Character.HumanoidRootPart.Position).Magnitude;

            if Magnitude < v3 then
                v4 = descendant;
                v3 = Magnitude;
            end;
        end;
    end;

    if v4 then
        u1 = v4;

        return;
    end;

    u1 = nil;
end;

while true do
    wait(0.5);
    local LocalPlayer = game.Players.LocalPlayer;
    local v5 = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Lockpick");
    findClosestDriveSeat(LocalPlayer);

    if v5 and u1 ~= nil then
        if u1:WaitForChild("Lockpick", 0.01) then
            u1.Lockpick.Enabled = true;
        end;
    elseif u1 ~= nil and u1:WaitForChild("Lockpick", 0.01) then
        u1.Lockpick.Enabled = false;
    end;
end;