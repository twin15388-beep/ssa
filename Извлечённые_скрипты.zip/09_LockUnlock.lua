-- Decompiled with Potassium's decompiler.

local function findClosestDriveSeat(p1) -- Line: 3
    local Character = p1.Character;
    local v2 = 15;
    local v3 = nil;

    for _, descendant in ipairs(workspace:GetDescendants()) do
        if descendant:IsA("VehicleSeat") then
            local Magnitude = (descendant.Position - Character.HumanoidRootPart.Position).Magnitude;

            if descendant:FindFirstChild("FromPlayer", true) and Magnitude < v2 then
                v3 = descendant;
                v2 = Magnitude;
            end;
        end;
    end;

    return v3;
end;

local function isSeatOccupiedByPlayerCharacter(p4) -- Line: 26
    return p4.Occupant == game.Players.LocalPlayer.Character;
end;

game:GetService("UserInputService").InputBegan:Connect(function(p5, p6) -- Line: 30, Name: onKeyPress
    -- upvalues: findClosestDriveSeat (copy)
    if p6 then
        return;
    end;

    local LocalPlayer = game.Players.LocalPlayer;

    if p5.KeyCode == Enum.KeyCode.L then
        local v7 = findClosestDriveSeat(LocalPlayer);

        if v7 then
            v7.FromPlayer:FireServer();

            return;
        end;

        print("No available drive seats within the range.");
    end;
end);